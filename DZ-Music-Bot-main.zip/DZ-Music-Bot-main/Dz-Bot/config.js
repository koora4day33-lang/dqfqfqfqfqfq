module.exports = {
    BOT_TOKEN: process.env.BOT_TOKEN || '',
    CLIENT_ID: process.env.CLIENT_ID || '1492908238616789192',
    OWNER_ID: process.env.OWNER_ID || '1264170106372755540',
    PREFIX: ',',


    LAVALINK: {
        HOSTS: process.env.LAVALINK_HOSTS || 'fi7.bot-hosting.net',
        PORTS: process.env.LAVALINK_PORTS || '21441',
        PASSWORDS: process.env.LAVALINK_PASSWORDS || 'DarkZone',
        SECURES: process.env.LAVALINK_SECURES || 'false'
    },


    MUSIC: {
        DEFAULT_PLATFORM: 'ytsearch', // 'youtube' or 'spotify' or 'soundcloud' or 'applemusic' or 'deezer' or 'yandexmusic'
        AUTOCOMPLETE_LIMIT: 5,
        PLAYLIST_LIMIT: 3,
        ARTWORK_STYLE: 'MusicCard' // 'Banner' for MediaGallery or 'MusicCard' for custom image card
    },

    GENIUS: {
        API_KEY: process.env.GENIUS_API_KEY || ''
    }
};
